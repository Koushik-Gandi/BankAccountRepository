package com.capgemini.bankaccountdetails.service;

import java.sql.ResultSet;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.bankaccountdetails.accountRepository.BankAccountRepoInter;
import com.capgemini.bankaccountdetails.exception.LowBalanceException;
import com.capgemini.bankaccountdetails.repository.BankAccountRepository;

@Component("bankAccountServiceImpl")
public class BankAccountServiceImpl implements BankAccountService {

	@Autowired
	private BankAccountRepository bankAccountRepositoryImpl;

	@Autowired
	private BankAccountRepoInter bankAccRepoInter;

	@PersistenceContext
	public EntityManager em;

	@Override
	public double withdraw(long accountId, double amount) throws LowBalanceException {

		long originalBal = em.createQuery("select balance from BankAccount where accountId=?")
				.setParameter(1, accountId).getFirstResult();

		if (originalBal > amount) {
			Query query = em.createQuery("update BankAccount set balance=balance-? where accountId=?")
					.setParameter(1, amount).setParameter(2, accountId);

			long bal = em.createQuery("select balance from BankAccount where accountId=?").setParameter(1, accountId)
					.getFirstResult();

			return bal;
		} else {
			throw new LowBalanceException("Low balance in account");
		}
	}

	@Override
	public double deposit(long accountId, double amount) {
		
		Query query = em.createQuery("update BankAccount set balance=balance+? where accountId=?")
				.setParameter(1, amount).setParameter(2, accountId);
		long bal = em.createQuery("select balance from BankAccount where accountId=?").setParameter(1, accountId)
				.getFirstResult();

		return bal;
		
	}

	@Override
	public double getBalance(long accountId) {
		return 0;
	}

	@Override
	public boolean fundTransfer(long fromAccount, long toAccount, double amont) {
		return false;
	}

}
