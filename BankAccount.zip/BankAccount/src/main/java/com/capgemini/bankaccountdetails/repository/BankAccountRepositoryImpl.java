package com.capgemini.bankaccountdetails.repository;

public class BankAccountRepositoryImpl implements BankAccountRepository {

	@Override
	public double getBalance(long accountId) {
		return 0;
	}

	@Override
	public double updateBalance(long accountId, double newBalance) {
		return 0;
	}

}
