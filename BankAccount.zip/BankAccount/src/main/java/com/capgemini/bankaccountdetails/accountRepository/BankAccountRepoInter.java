package com.capgemini.bankaccountdetails.accountRepository;

import org.springframework.data.repository.CrudRepository;

public interface BankAccountRepoInter extends CrudRepository<BankAccountRepoInter, Long> {

}
