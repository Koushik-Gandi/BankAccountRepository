package com.capgemini.bankaccountdetails.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bankaccountdetails.service.BankAccountService;

@RestController
public class BankAccountController {

	@Autowired
	private BankAccountService bankAccountServiceImpl;

	@PutMapping("/withdraw")
	public double withdraw(long accountId, double balance) {
		bankAccountServiceImpl.withdraw(accountId, balance);
		return balance;
	}

	@PutMapping("/deposit")
	public double deposit(long accountId, double balance) {
		bankAccountServiceImpl.deposit(accountId, balance);
		return balance;
	}

	@GetMapping("/getBalance")
	public double getBalance(@PathVariable long accountId) {
		bankAccountServiceImpl.getBalance(accountId);
		return accountId;
	}

	@PutMapping("/fundTransfer")
	public boolean fundTransfer(long fromAccount, long toAccount, double amount) {
		bankAccountServiceImpl.fundTransfer(fromAccount, toAccount, amount);
		return false;
	}
}
