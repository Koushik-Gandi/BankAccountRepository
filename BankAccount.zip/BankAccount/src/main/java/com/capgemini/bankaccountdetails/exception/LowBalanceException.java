package com.capgemini.bankaccountdetails.exception;

public class LowBalanceException extends Exception {
	public LowBalanceException() {
		// TODO Auto-generated constructor stub
	}

	public LowBalanceException(String message) {
		super(message);
	}
}
