package com.capgemini.bankaccountdetails.service;

import org.springframework.stereotype.Service;

import com.capgemini.bankaccountdetails.exception.LowBalanceException;

@Service
public interface BankAccountService {
	public double withdraw(long accountId, double balance) throws LowBalanceException;

	public double deposit(long accountId, double balance);

	public double getBalance(long accountId);

	public boolean fundTransfer(long fromAccount, long toAccount, double amount);
}
